# Plot functions
import matplotlib.pyplot as plt
